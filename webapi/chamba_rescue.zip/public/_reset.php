<?php
header('Content-Type: text/plain; charset=utf-8');
$base = realpath(__DIR__ . '/..');
if (!$base) { http_response_code(500); exit("base no resuelto\n"); }
$report = [];

$dirs = ['storage/app','storage/app/public','storage/app/private','storage/framework','storage/framework/cache','storage/framework/cache/data','storage/framework/sessions','storage/framework/testing','storage/framework/views','storage/logs'];
foreach ($dirs as $rel) {
    $abs = $base.'/'.$rel;
    if (!is_dir($abs)) { @mkdir($abs, 0775, true); $report[] = "creado: $rel"; }
    else { $report[] = "(ok): $rel"; }
    $gi = $abs.'/.gitignore';
    if (is_dir($abs) && !file_exists($gi)) @file_put_contents($gi, "*\n!.gitignore\n");
}
foreach (['storage','bootstrap/cache'] as $rel) {
    $abs = $base.'/'.$rel;
    if (is_dir($abs)) {
        @chmod($abs, 0775);
        try {
            $iter = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($abs, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
            foreach ($iter as $item) @chmod($item->getPathname(), $item->isDir() ? 0775 : 0664);
        } catch (\Throwable $e) {}
        $report[] = "chmod: $rel";
    }
}
foreach (['config.php','routes-v7.php','services.php','packages.php','events.php'] as $f) {
    $p = $base.'/bootstrap/cache/'.$f;
    if (file_exists($p)) { @unlink($p); $report[] = "borrado: bootstrap/cache/$f"; }
}
$views = $base.'/storage/framework/views';
if (is_dir($views)) { foreach (glob($views.'/*.php') as $v) @unlink($v); $report[] = "vistas compiladas limpiadas"; }

$envOk = file_exists($base.'/.env');
$vendorOk = file_exists($base.'/vendor/autoload.php');
$report[] = ".env existe: " . ($envOk ? 'SI' : 'NO');
$report[] = "vendor/autoload.php existe: " . ($vendorOk ? 'SI' : 'NO');

// Probar bootstrap m?nimo de Laravel para confirmar que arranca
if ($envOk && $vendorOk) {
    try {
        require $base . '/vendor/autoload.php';
        $app = require_once $base . '/bootstrap/app.php';
        $kernel = $app->make(\Illuminate\Contracts\Http\Kernel::class);
        $report[] = "bootstrap Laravel: OK (env=" . $app->environment() . ")";
    } catch (\Throwable $e) {
        $report[] = "bootstrap Laravel ERROR: " . get_class($e) . ": " . $e->getMessage();
        $report[] = "  en " . $e->getFile() . ":" . $e->getLine();
    }
}

clearstatcache();
foreach (['public/index.php','bootstrap/app.php','.htaccess','routes/web.php','routes/api.php'] as $rel) {
    $abs = $base.'/'.$rel;
    if (file_exists($abs)) { @touch($abs); if (function_exists('opcache_invalidate')) @opcache_invalidate($abs, true); $report[] = "touch: $rel"; }
}
echo "=== RESET ===\n".implode("\n",$report)."\n\nProba:\n  https://jaapsystem.com/v1/chamba/app\n  https://jaapsystem.com/v1/chamba/api/v1/categories\n\nBORRA public/_reset.php y public/_diag.php cuando termines.\n";
