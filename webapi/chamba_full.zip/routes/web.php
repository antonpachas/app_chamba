<?php

use App\Http\Controllers\SetupController;
use App\Http\Controllers\SitemapController;
use App\Http\Controllers\SocialAuthController;
use Illuminate\Support\Facades\Route;

/**
 * Endpoint de bootstrap remoto para shared hosting sin terminal.
 * Protegido por token (CHAMBA_SETUP_TOKEN en .env). Inactivo si el token está vacío.
 */
Route::get('/setup', SetupController::class);

/** Mapa de sitio para motores de búsqueda. */
Route::get('/sitemap.xml', SitemapController::class.'@index')->name('chamba.sitemap');

/** Google OAuth — popup abierto desde el SPA Vue. */
Route::get('/auth/google/redirect', [SocialAuthController::class, 'redirectToGoogle'])->name('auth.google.redirect');
Route::get('/auth/google/callback', [SocialAuthController::class, 'handleGoogleCallback'])->name('auth.google.callback');

/** robots.txt — permite indexar la SPA y apunta al sitemap. */
Route::get('/robots.txt', function () {
    $sitemap = url('/sitemap.xml');
    $body    = implode("\n", [
        'User-agent: *',
        'Allow: /',
        "Sitemap: {$sitemap}",
        '',
    ]);
    return response($body, 200, ['Content-Type' => 'text/plain']);
});

/** Redirección desde la portada anterior. */
Route::redirect('/portada', '/app', 302);

/** Sitio raíz: enviar a la app SPA. */
Route::redirect('/', '/app');

/**
 * site.webmanifest dinámico. Sirve el manifest con URLs absolutas que
 * respetan APP_URL (necesario en deploys en subdirectorio: /v1/chamba/...).
 * Si lo dejamos como JSON estático, las rutas `/img/...` y `/app` apuntan
 * al dominio raíz y dan 404 dentro de un subdirectorio.
 */
Route::get('/site.webmanifest', function () {
    return response()->json([
        'name' => 'Busca PE — Servicios locales',
        'short_name' => 'Busca PE',
        'description' => 'Encuentra negocios y profesionales cerca de ti.',
        'start_url' => url('/app'),
        'scope' => url('/app'),
        'display' => 'standalone',
        'orientation' => 'portrait',
        'background_color' => '#FFFFFF',
        'theme_color' => '#003874',
        'lang' => 'es-PE',
        'icons' => [
            ['src' => asset('img/icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
            ['src' => asset('img/icon-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
            ['src' => asset('img/icon-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
        ],
    ])->header('Content-Type', 'application/manifest+json');
})->name('chamba.manifest');

/**
 * SPA Vue. Cualquier sub-ruta dentro de /app la maneja vue-router.
 * Registramos /app y /app/{any} por separado para que también acepte la
 * variante con trailing slash sin depender solo del rewrite de Apache.
 */
Route::view('/app', 'chamba.app')->name('chamba.app');
Route::view('/app/{any}', 'chamba.app')->where('any', '.*');
