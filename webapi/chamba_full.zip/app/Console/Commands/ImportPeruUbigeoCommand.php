<?php

namespace App\Console\Commands;

use App\Models\Department;
use App\Models\District;
use App\Models\Province;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;

final class ImportPeruUbigeoCommand extends Command
{
    protected $signature = 'chamba:import-peru-ubigeo
                            {--url= : URL CSV (default: ubigeo-peru-aumentado)}
                            {--file= : Ruta local al CSV (evita descarga HTTP)}
                            {--fresh : Vacía tablas geo antes de importar (¡cuidado en producción!)}';

    protected $description = 'Importa departamentos, provincias y distritos del Perú (UBIGEO INEI + coordenadas)';

    private const DEFAULT_CSV_URL = 'https://raw.githubusercontent.com/jmcastagnetto/ubigeo-peru-aumentado/main/ubigeo_distrito.csv';

    public function handle(): int
    {
        if (! Schema::hasTable('departments')) {
            $this->error('Faltan tablas geo. Ejecuta las migraciones del proyecto.');

            return self::FAILURE;
        }

        $file = (string) $this->option('file');
        if ($file !== '' && is_file($file)) {
            $this->info("Leyendo catálogo desde archivo: {$file}");
            $body = (string) file_get_contents($file);
        } else {
            $url = (string) ($this->option('url') ?: self::DEFAULT_CSV_URL);
            $this->info("Descargando catálogo desde: {$url}");

            $response = Http::timeout(120)->get($url);
            if (! $response->successful()) {
                $this->error('No se pudo descargar el CSV de ubigeo. Usa --file=ruta/local.csv si hay problemas SSL.');

                return self::FAILURE;
            }
            $body = $response->body();
        }

        $lines = preg_split('/\r\n|\r|\n/', trim($body));
        if ($lines === false || count($lines) < 2) {
            $this->error('CSV vacío o inválido.');

            return self::FAILURE;
        }

        if ($this->option('fresh')) {
            if (! $this->confirm('¿Vaciar departments, provinces y districts? Esto puede romper FKs si hay datos.')) {
                return self::SUCCESS;
            }
            DB::statement('SET FOREIGN_KEY_CHECKS=0');
            District::query()->delete();
            Province::query()->delete();
            Department::query()->delete();
            DB::statement('SET FOREIGN_KEY_CHECKS=1');
            $this->warn('Tablas geo vaciadas.');
        }

        $header = str_getcsv(array_shift($lines));
        $idx = array_flip(array_map('strtolower', $header));

        foreach (['inei', 'departamento', 'provincia', 'distrito', 'latitude', 'longitude'] as $col) {
            if (! isset($idx[$col])) {
                $this->error("Columna «{$col}» no encontrada en CSV.");

                return self::FAILURE;
            }
        }

        $deptIds = [];
        $provIds = [];
        $countDept = 0;
        $countProv = 0;
        $countDist = 0;

        foreach ($lines as $line) {
            if (trim($line) === '') {
                continue;
            }
            $row = str_getcsv($line);
            if (count($row) < 6) {
                continue;
            }

            $inei = str_pad(preg_replace('/\D/', '', (string) $row[$idx['inei']]), 6, '0', STR_PAD_LEFT);
            if (strlen($inei) !== 6) {
                continue;
            }

            $deptCode = substr($inei, 0, 2);
            $provCode = substr($inei, 0, 4);
            $deptName = trim((string) $row[$idx['departamento']]);
            $provName = trim((string) $row[$idx['provincia']]);
            $distName = trim((string) $row[$idx['distrito']]);
            $lat = $this->floatOr($row[$idx['latitude']] ?? null, -12.046374);
            $lng = $this->floatOr($row[$idx['longitude']] ?? null, -77.042793);

            if ($deptName === '' || $provName === '' || $distName === '') {
                continue;
            }

            if (! isset($deptIds[$deptCode])) {
                $dept = $this->upsertDepartment($deptCode, $deptName, $lat, $lng);
                $deptIds[$deptCode] = (int) $dept->id;
                $countDept++;
            }

            if (! isset($provIds[$provCode])) {
                $prov = $this->upsertProvince($provCode, $deptIds[$deptCode], $provName, $lat, $lng);
                $provIds[$provCode] = (int) $prov->id;
                $countProv++;
            }

            $this->upsertDistrict($inei, $provIds[$provCode], $distName, $lat, $lng);
            $countDist++;
        }

        $this->info("Importación lista: ~{$countDept} deptos, ~{$countProv} prov., {$countDist} distritos procesados.");
        $this->line('Departamentos en BD: '.Department::query()->count());
        $this->line('Provincias en BD: '.Province::query()->count());
        $this->line('Distritos en BD: '.District::query()->count());

        return self::SUCCESS;
    }

    private function upsertDepartment(string $deptCode, string $deptName, float $lat, float $lng): Department
    {
        $payload = [
            'name' => $deptName,
            'latitude' => $lat,
            'longitude' => $lng,
            'is_active' => true,
        ];
        if (Schema::hasColumn('departments', 'ubigeo_code')) {
            $payload['ubigeo_code'] = $deptCode;
        }

        $dept = null;
        if (Schema::hasColumn('departments', 'ubigeo_code')) {
            $dept = Department::query()->where('ubigeo_code', $deptCode)->first();
        }
        if (! $dept) {
            $dept = Department::query()->whereRaw('LOWER(name) = ?', [mb_strtolower($deptName)])->first();
        }
        if ($dept) {
            $dept->fill($payload)->save();

            return $dept;
        }

        return Department::query()->create($payload);
    }

    private function upsertProvince(string $provCode, int $departmentId, string $provName, float $lat, float $lng): Province
    {
        $payload = [
            'department_id' => $departmentId,
            'name' => $provName,
            'latitude' => $lat,
            'longitude' => $lng,
            'is_active' => true,
        ];
        if (Schema::hasColumn('provinces', 'ubigeo_code')) {
            $payload['ubigeo_code'] = $provCode;
        }

        $prov = null;
        if (Schema::hasColumn('provinces', 'ubigeo_code')) {
            $prov = Province::query()->where('ubigeo_code', $provCode)->first();
        }
        if (! $prov) {
            $prov = Province::query()
                ->where('department_id', $departmentId)
                ->whereRaw('LOWER(name) = ?', [mb_strtolower($provName)])
                ->first();
        }
        if ($prov) {
            $prov->fill($payload)->save();

            return $prov;
        }

        return Province::query()->create($payload);
    }

    private function upsertDistrict(string $inei, int $provinceId, string $distName, float $lat, float $lng): District
    {
        $payload = [
            'province_id' => $provinceId,
            'name' => $distName,
            'latitude' => $lat,
            'longitude' => $lng,
            'is_active' => true,
        ];
        if (Schema::hasColumn('districts', 'ubigeo')) {
            $payload['ubigeo'] = $inei;
        }

        $dist = null;
        if (Schema::hasColumn('districts', 'ubigeo')) {
            $dist = District::query()->where('ubigeo', $inei)->first();
        }
        if (! $dist) {
            $dist = District::query()
                ->where('province_id', $provinceId)
                ->whereRaw('LOWER(name) = ?', [mb_strtolower($distName)])
                ->first();
        }
        if ($dist) {
            $dist->fill($payload)->save();

            return $dist;
        }

        return District::query()->create($payload);
    }

    private function floatOr(mixed $value, float $fallback): float
    {
        if ($value === null || $value === '') {
            return $fallback;
        }
        $n = (float) str_replace(',', '.', (string) $value);

        return ($n >= -90 && $n <= 90) ? $n : $fallback;
    }
}
