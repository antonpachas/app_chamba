<script setup>
import { computed } from 'vue';

const props = defineProps({
    schedule: { type: Object, default: null },
    compact: { type: Boolean, default: false },
});

const days = [
    { key: 'mon', label: 'Lun' },
    { key: 'tue', label: 'Mar' },
    { key: 'wed', label: 'Mié' },
    { key: 'thu', label: 'Jue' },
    { key: 'fri', label: 'Vie' },
    { key: 'sat', label: 'Sáb' },
    { key: 'sun', label: 'Dom' },
];

const rows = computed(() => {
    const s = props.schedule;
    if (!s || typeof s !== 'object') return [];
    return days.map(({ key, label }) => {
        const block = s[key] || s[key.toUpperCase()];
        if (!block || typeof block !== 'object') {
            return { label, text: '—' };
        }
        if (block.closed) {
            return { label, text: 'Cerrado', closed: true };
        }
        const open = String(block.open || '').trim();
        const close = String(block.close || '').trim();
        if (open && close) {
            return { label, text: `${open} – ${close}` };
        }
        return { label, text: '—' };
    });
});

const hasAny = computed(() => rows.value.some((r) => r.text !== '—'));
</script>

<template>
    <div v-if="hasAny" class="rounded-xl border border-slate-100 bg-slate-50/80 overflow-hidden">
        <p class="text-xs font-bold uppercase tracking-wide text-slate-500 px-4 pt-3 pb-2">Horario de atención</p>
        <ul class="divide-y divide-slate-100" :class="compact ? 'text-xs' : 'text-sm'">
            <li
                v-for="row in rows"
                :key="row.label"
                class="flex justify-between gap-3 px-4 py-2"
            >
                <span class="font-bold text-slate-600 w-10 shrink-0">{{ row.label }}</span>
                <span class="text-right font-medium" :class="row.closed ? 'text-slate-400' : 'text-slate-800'">
                    {{ row.text }}
                </span>
            </li>
        </ul>
    </div>
</template>
