<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ProviderProfile extends Model
{
    protected $fillable = [
        'user_id',
        'business_name',
        'description',
        'whatsapp',
        'contact_phone',
        'address_text',
        'district_id',
        'listing_duration_days_override',
        'is_verified',
        'avg_rating',
        'total_reviews',
    ];

    protected function casts(): array
    {
        return [
            'is_verified' => 'boolean',
            'listing_duration_days_override' => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function district(): BelongsTo
    {
        return $this->belongsTo(District::class);
    }

    public function providerServices(): HasMany
    {
        return $this->hasMany(ProviderService::class);
    }

    public function locations(): HasMany
    {
        return $this->hasMany(ProviderLocation::class)->orderByDesc('is_primary')->orderBy('label');
    }

    public function activeLocations(): HasMany
    {
        return $this->hasMany(ProviderLocation::class)->where('is_active', 1)->orderByDesc('is_primary')->orderBy('label');
    }
}
