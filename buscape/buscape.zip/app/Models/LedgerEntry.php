<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LedgerEntry extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'type', 'category', 'amount', 'currency',
        'description', 'reference_type', 'reference_id',
        'recorded_by', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'     => 'decimal:2',
            'created_at' => 'datetime',
        ];
    }
}
